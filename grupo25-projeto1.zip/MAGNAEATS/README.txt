# Projeto Sistemas Operativos - Fase 1

Afonso Santos - FC56368
Alexandre Figueiredo - FC57099
Raquel Domingos - FC56378

Os id's dos restaurantes, motoristas e clientes comecam a 1.
Os id's dos pedidos começam a 0.