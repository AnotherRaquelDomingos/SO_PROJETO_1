/*
* Função que conta o número de dígitos de um número inteiro.
*/
int numDigits(int);

/*
* Função que determina o número de caracteres numa string.
*/
int stringSize(char*);